public abstract class Tire {

}
