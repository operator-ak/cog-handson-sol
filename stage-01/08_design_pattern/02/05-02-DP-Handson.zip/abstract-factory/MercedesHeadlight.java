public class MercedesHeadlight extends Headlight {
  public MercedesHeadlight() {
    System.out.println("MercedesHeadlight");
  }
}
