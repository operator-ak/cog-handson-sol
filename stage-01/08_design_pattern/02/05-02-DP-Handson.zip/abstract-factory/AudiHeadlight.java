public class AudiHeadlight extends Headlight {
  public AudiHeadlight() {
    System.out.println("AudiHeadlight");
  }
}
