public class MercedesTire extends Tire {
  public MercedesTire() {
    System.out.println("MercedesTire");
  }
}
