public abstract class Headlight {

}
