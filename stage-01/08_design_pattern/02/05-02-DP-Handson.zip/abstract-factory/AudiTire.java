public class AudiTire extends Tire {
  public AudiTire() {
    System.out.println("AudiTire");
  }
}
