public class Main {
  public static void main(String[] args) {
    DBConn db = DBConn.getInstance();

    db.save();
  }
}
