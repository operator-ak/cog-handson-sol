public interface IOrder {
  void processOrder(String modelName);
}
