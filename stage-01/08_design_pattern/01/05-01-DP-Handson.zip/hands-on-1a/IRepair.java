public interface IRepair {
  void processPhoneRepair(String modelName);

  void processAccessoryRepair(String accessoryType);
}
