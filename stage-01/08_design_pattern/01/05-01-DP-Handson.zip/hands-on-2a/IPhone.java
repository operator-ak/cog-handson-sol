public interface IPhone {
  String getPhonePart1();

  Double getPart1Cost();
}