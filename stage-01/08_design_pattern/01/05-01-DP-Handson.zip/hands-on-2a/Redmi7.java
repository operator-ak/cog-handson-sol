public class Redmi7 implements IPhone {

  @Override
  public String getPhonePart1() {
    return "Display";
  }

  @Override
  public Double getPart1Cost() {
    return 500.0d;
  }

}
