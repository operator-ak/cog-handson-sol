public interface Observer {
  public void update(Message message);
}
