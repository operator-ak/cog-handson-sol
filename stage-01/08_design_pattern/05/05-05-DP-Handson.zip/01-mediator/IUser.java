public interface IUser {
  public void receiveMessage(String message);

  public void sendMessage(String message);
}
